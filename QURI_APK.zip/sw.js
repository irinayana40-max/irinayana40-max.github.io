const CACHE = 'quri-v1';
const ASSETS = [
  '/quri/lengua-senas.html',
  '/quri/manifest.json',
  '/quri/logo-quri.png'
];

self.addEventListener('install', e => {
  e.waitUntil(caches.open(CACHE).then(c => c.addAll(ASSETS)));
});

self.addEventListener('fetch', e => {
  e.respondWith(
    caches.match(e.request).then(r => r || fetch(e.request))
  );
});
